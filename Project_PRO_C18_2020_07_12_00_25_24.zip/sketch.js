//Global Variables
var bananaImage,obstacleImage,backgroundImage,score,obstacleGroup,monkeyImage,background1,monkey,ground,bananaGroup,score


function preload(){
  bananaImage=loadImage("Banana.png");
  monkeyImage=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png")
  backgroundImage=loadImage("jungle.jpg");
  obstacleImage=loadImage("stone.png");
}


function setup() {
  createCanvas(600,300);
  background1 = createSprite(300,150,400,20);
  background1.addImage("back",backgroundImage);
  monkey=createSprite(40,250,20,20);
  monkey.addAnimation("monkey",monkeyImage);
  monkey.scale=0.15;
  ground = createSprite(300,300,600,20);
  ground.visible = false;
  bananaGroup= new Group();
  obstacleGroup= new Group();
  score=0;
  stroke("white")
  textSize(20)
  fill("white");
  
  
}


function draw(){
   background(225);
  
   
  
   if(keyDown("space"))
  {
    monkey.velocityY=-10;
    
  }
 monkey.collide(ground);
  monkey.velocityY = monkey.velocityY + 0.8;
  food();
  obstacles();
  
  if(bananaGroup.isTouching(monkey))
  {
    score=score+2;
    bananaGroup.destroyEach();
  }
  switch(score){
    case 10:monkey.scale=0.18;
      break;
    case 20:monkey.scale=0.21;
      break;
    case 30:monkey.scale=0.24;
      break;
    case 40:monkey.scale=0.27;
      break;
      default: break;
     }
  if(obstacleGroup.isTouching(monkey))
  {
    monkey.scale=0.15;
    
  }
  drawSprites();
  stroke("white");
  textSize(20)
  fill("white");
  
  text("Score: "+ score,500,50); 
  
}
function food()
{
  if(World.frameCount % 80 === 0)
  {
   
    
    var banana = createSprite(600,200);
    banana.y = Math.round(random(100,200));
    banana.addImage("ban", bananaImage);
    banana.scale=0.06;
    banana.velocityX=-2;
    banana.lifetime=300;
    bananaGroup.add(banana);
    
    
    
  }
  
  
}
function obstacles()
{
  if(World.frameCount % 300 === 0)
  {
   
    
    var obstacle = createSprite(600,250);
    obstacle.addImage("stone",obstacleImage);
    obstacle.scale=.3;
    obstacle.velocityX=-2;
    obstacle.lifetime=300;
    obstacleGroup.add(obstacle);
    
    
    
  }
}
  